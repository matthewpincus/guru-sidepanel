const USER_NAME = 'matthew.pincus@gethelpt.com';
const USER_TOKEN = 'aebb6e1e-aee2-4c3f-9e83-0bf7dacea4b9';
const API_URL = 'https://api.getguru.com/api/v1';

// Collection tokens
const COLLECTION_TOKENS = {
  default: 'f055fdba-e132-47fe-92de-a9eac2218ba2',
  collection2: '29647c42-4c94-45a1-8a9a-a95c290a794d',
  collection3: 'b86f6798-00c6-4fc2-908c-a63ddc933909',
  collection4: '87e018a0-cec0-4e48-8e31-b68d75cddb6a'
};

// Currently selected collection
let currentCollection = 'default';

let debounceTimer;

async function fetchGuruCards(query = '') {
  try {
    const searchableFields = ['title', 'content', 'preferredPhrase', 'alternatePhrase', 'tags'];
    const url = `${API_URL}/search/query?searchTerms=${encodeURIComponent(query)}&searchableFields=${searchableFields.join(',')}`;
    console.log('Fetching from URL:', url);
    
    const allResults = [];

    for (const [collectionName, collectionToken] of Object.entries(COLLECTION_TOKENS)) {
      const headers = {
        'Authorization': `Basic ${btoa(USER_NAME + ':' + USER_TOKEN)}`,
        'X-Guru-Collection-Token': collectionToken
      };
      console.log(`Request headers for ${collectionName}:`, headers);
      
      const response = await fetch(url, { headers });
      
      console.log(`Response status for ${collectionName}:`, response.status);
      
      if (!response.ok) {
        console.error(`HTTP error for ${collectionName}! status: ${response.status}`);
        continue;
      }
      
      const data = await response.json();
      console.log(`Full parsed data for ${collectionName}:`, data);
      
      if (Array.isArray(data)) {
        console.log(`Number of results for ${collectionName}:`, data.length);
        allResults.push(...data);
      } else {
        console.log(`Unexpected data structure for ${collectionName}`);
      }
    }

    console.log('All results:', allResults);
    return allResults;
  } catch (error) {
    console.error('Error fetching Guru cards:', error);
    return [];
  }
}

function displaySuggestions(cards) {
  const suggestionsContainer = document.getElementById('suggestions');
  suggestionsContainer.innerHTML = '';
  console.log('Displaying suggestions for cards:', cards);
  if (cards.length === 0) {
    suggestionsContainer.innerHTML = '<div class="suggestion">No results found</div>';
    return;
  }
  cards.slice(0, 5).forEach(card => {
    console.log('Card details:', {
      preferredPhrase: card.preferredPhrase,
      snippet: card.content.substring(0, 100).replace(/<[^>]*>/g, '') + '...',
      collection: card.collection ? card.collection.name : 'Unknown collection',
      tags: card.tags
    });
    const suggestion = document.createElement('div');
    suggestion.className = 'suggestion';
    suggestion.innerHTML = `
      <strong>${card.preferredPhrase}</strong>
    `;
    suggestion.addEventListener('click', () => addCard(card));
    suggestionsContainer.appendChild(suggestion);
  });
  
  // Make suggestions container collapsible
  const collapseButton = document.createElement('button');
  collapseButton.textContent = 'Collapse Results';
  collapseButton.className = 'collapse-button';
  collapseButton.addEventListener('click', toggleSuggestions);
  suggestionsContainer.prepend(collapseButton);
}

function toggleSuggestions() {
  const suggestionsContainer = document.getElementById('suggestions');
  const collapseButton = suggestionsContainer.querySelector('.collapse-button');
  if (suggestionsContainer.classList.toggle('collapsed')) {
    collapseButton.textContent = 'Expand Results';
  } else {
    collapseButton.textContent = 'Collapse Results';
  }
}

function addCard(card) {
  const cardsContainer = document.getElementById('cards-container');
  const cardElement = document.createElement('div');
  cardElement.className = 'card';
  cardElement.innerHTML = `
    <div class="card-header">
      <h3>${card.preferredPhrase}</h3>
      <button class="close-btn">&times;</button>
    </div>
    <div class="card-content">${card.content}</div>
    <button class="back-to-results-btn">Back to Results</button>
  `;
  cardElement.querySelector('.close-btn').addEventListener('click', () => cardElement.remove());
  cardElement.querySelector('.back-to-results-btn').addEventListener('click', () => {
    cardElement.remove();
    toggleSuggestions();
  });
  
  // Intercept clicks on Guru card links
  const cardContent = cardElement.querySelector('.card-content');
  cardContent.addEventListener('click', async (e) => {
    if (e.target.tagName === 'A') {
      e.preventDefault();
      if (e.target.href.includes('app.getguru.com/card/')) {
        const cardId = e.target.href.split('/').pop();
        const newCard = await fetchGuruCardBySlug(cardId);
        if (newCard) {
          cardElement.remove();
          addCard(newCard);
        }
      } else {
        window.open(e.target.href, '_blank');
      }
    }
  });

  // Add hover effects for links
  cardContent.addEventListener('mouseover', (e) => {
    if (e.target.tagName === 'A') {
      const isGuruCard = e.target.href.includes('app.getguru.com/card/');
      e.target.title = isGuruCard ? 'Open in side panel' : 'Open in new tab';
      e.target.style.textDecoration = 'underline';
      e.target.style.cursor = 'pointer';
    }
  });

  cardContent.addEventListener('mouseout', (e) => {
    if (e.target.tagName === 'A') {
      e.target.style.textDecoration = 'none';
    }
  });
  
  cardsContainer.prepend(cardElement);
  document.getElementById('search-input').value = '';
  toggleSuggestions();
}

async function fetchGuruCardBySlug(slug) {
  try {
    const url = `${API_URL}/search/query?searchTerms=${encodeURIComponent(slug)}`;
    const headers = {
      'Authorization': `Basic ${btoa(USER_NAME + ':' + USER_TOKEN)}`
    };
    console.log('Fetching card from URL:', url);
    const response = await fetch(url, { headers });
    if (!response.ok) {
      console.error(`HTTP error! status: ${response.status}`);
      const text = await response.text();
      console.error('Response text:', text);
      return null;
    }
    const data = await response.json();
    console.log('Fetched data:', data);
    if (Array.isArray(data) && data.length > 0) {
      return data[0]; // Return the first card that matches the slug
    }
    console.error('No matching card found');
    return null;
  } catch (error) {
    console.error('Error fetching Guru card:', error);
    return null;
  }
}

function debounce(func, delay) {
  return function() {
    const context = this;
    const args = arguments;
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => func.apply(context, args), delay);
  };
}

const performSearch = debounce(async () => {
  const query = document.getElementById('search-input').value;
  console.log('Performing search for:', query);
  if (query.length > 2) {
    const cards = await fetchGuruCards(query);
    console.log('Received cards:', cards);
    console.log('Number of cards:', cards.length);
    displaySuggestions(cards);
  } else {
    console.log('Query too short, clearing suggestions');
    document.getElementById('suggestions').innerHTML = '';
  }
}, 300);

// Function to change the current collection
function changeCollection(collectionKey) {
  if (COLLECTION_TOKENS[collectionKey]) {
    currentCollection = collectionKey;
    // Optionally, you can trigger a new search or update the UI here
  } else {
    console.error('Invalid collection key');
  }
}

// Simple drag and drop functionality
function dragStart(e) {
  e.dataTransfer.setData('text/plain', e.target.id);
  setTimeout(() => e.target.classList.add('dragging'), 0);
}

function dragOver(e) {
  e.preventDefault();
  const draggingElement = document.querySelector('.dragging');
  const cardContainer = document.getElementById('cards-container');
  const afterElement = getDragAfterElement(cardContainer, e.clientY);
  if (afterElement == null) {
    cardContainer.appendChild(draggingElement);
  } else {
    cardContainer.insertBefore(draggingElement, afterElement);
  }
}

function getDragAfterElement(container, y) {
  const draggableElements = [...container.querySelectorAll('.card:not(.dragging)')];
  return draggableElements.reduce((closest, child) => {
    const box = child.getBoundingClientRect();
    const offset = y - box.top - box.height / 2;
    if (offset < 0 && offset > closest.offset) {
      return { offset: offset, element: child };
    } else {
      return closest;
    }
  }, { offset: Number.NEGATIVE_INFINITY }).element;
}

function drop(e) {
  e.preventDefault();
  document.querySelector('.dragging').classList.remove('dragging');
}

document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('search-input');
  searchInput.addEventListener('input', performSearch);

  const cardsContainer = document.getElementById('cards-container');
  cardsContainer.addEventListener('dragover', dragOver);
  cardsContainer.addEventListener('drop', drop);

  // If you want to add a collection selector, you can do it here
  // For example:
  // const collectionSelector = document.getElementById('collection-selector');
  // collectionSelector.addEventListener('change', (e) => changeCollection(e.target.value));
});

// To add more collections:
// 1. Add the new collection token to the COLLECTION_TOKENS object
// 2. Create a UI element (e.g., a dropdown) to allow users to select the collection
// 3. Call changeCollection(newCollectionKey) when the user selects a different collection
