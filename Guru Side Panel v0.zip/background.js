chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
